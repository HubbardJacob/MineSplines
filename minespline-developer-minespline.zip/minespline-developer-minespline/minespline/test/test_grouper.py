
from minespline.grouper import groupmines



def test_grouper_one():
    # When mines are evenly spaced on a straight line
    # Then we should find them all


    assert False
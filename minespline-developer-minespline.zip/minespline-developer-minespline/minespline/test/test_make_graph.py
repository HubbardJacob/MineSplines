import numpy as np

from minespline.mineliner_matrix import make_graph, build_corners, make_graph_from_valid


def test_make_graph():
    points = np.random.rand(1000, 3)

    results = make_graph(0.1, points)
    degrees, edges, edge_lengths = results ## can be used in asserts

def test_make_corners():
    points = np.random.rand(10, 3)



    valid, degrees, edges, edge_lengths = make_graph(0.3, points)
    print(edges)

    corners, corner_count, corner_start = build_corners(valid, degrees, edges) ## can be used in asserts
    print(corners)

def test_basic_test():
    test_d = [[0,1,1,1,1],
              [1,0,1,0,1],
              [1,1,0,1,0],
              [1,0,1,0,1],
              [1,1,0,1,0]]

    # test_d = [[0, 1, 0],
    #          [1, 0, 1],
    #          [0, 1, 0]]
    test_d = np.array(test_d)
    distances = [[1, 2, 3,  4,  5],
                 [2, 6, 7,  8,  9],
                 [3, 7, 10, 11, 12],
                 [4, 8, 11, 13, 14],
                 [5, 9, 12, 14, 15]]
    distances = np.array(distances)
    # expected_edges = [[0,1], []]
    valid, degrees, edges, edge_lengths = make_graph_from_valid(distances, test_d == 1)

    itemindex = np.where(np.all(edges == (2,3), axis=1))

    assert edges[1][0] == 0
    assert edges[1][1] == 2
    assert degrees[0] == 4
    assert edge_lengths[0] == 2
    assert itemindex[0] == 9
    assert edge_lengths[itemindex[0]] == 11


